// Language toggle
function setLang(l) {
  document.body.className = 'lang-' + l;
  document.querySelectorAll('.lang-b').forEach(b => b.classList.toggle('on', b.textContent.toLowerCase() === l));
  document.documentElement.lang = l === 'id' ? 'id' : 'en';
  localStorage.setItem('zyvo-lang', l);
}
// Load saved language
const saved = localStorage.getItem('zyvo-lang');
if (saved) setLang(saved);

// Mobile menu
function toggleMobile() {
  const m = document.getElementById('mobileMenu'), b = document.getElementById('mobBtn');
  const o = m.classList.toggle('open');
  b.textContent = o ? '✕' : '☰';
}
function closeMobile() {
  document.getElementById('mobileMenu').classList.remove('open');
  document.getElementById('mobBtn').textContent = '☰';
}

// FAQ accordion
function toggleFaq(btn) {
  const i = btn.parentElement, w = i.classList.contains('open');
  document.querySelectorAll('.faq-i').forEach(x => x.classList.remove('open'));
  if (!w) i.classList.add('open');
}

// Currency toggle
function showC(c) {
  document.querySelectorAll('.c').forEach(el => { el.style.display = el.classList.contains(c) ? '' : 'none' });
  document.querySelectorAll('.cur-b').forEach(b => { b.classList.toggle('on', b.textContent.toLowerCase() === c) });
}

// Form submission
function submitForm() {
  const n = document.getElementById('fname').value.trim(), e = document.getElementById('femail').value.trim();
  if (!n || !e) { alert(document.body.classList.contains('lang-id') ? 'Mohon isi nama dan email Anda.' : 'Please fill in your name and email.'); return }
  if (!e.includes('@') || !e.includes('.')) { alert(document.body.classList.contains('lang-id') ? 'Mohon masukkan email yang valid.' : 'Please enter a valid email.'); return }
  const biz = document.getElementById('fbiz')?.value.trim() || '', web = document.getElementById('fweb')?.value.trim() || '', plan = document.getElementById('fplan')?.value || '', msg = document.getElementById('fmsg')?.value.trim() || '';
  const s = encodeURIComponent('Free Preview Request — ' + (biz || n));
  const b = encodeURIComponent('Name: ' + n + '\nEmail: ' + e + '\nBusiness: ' + (biz || 'N/A') + '\nWebsite: ' + (web || 'None') + '\nPlan: ' + (plan || 'Not specified') + '\n\nMessage:\n' + (msg || 'No additional message.'));
  window.open('mailto:roy@zyphora.io?subject=' + s + '&body=' + b, '_self');
  if (document.getElementById('formFields')) document.getElementById('formFields').style.display = 'none';
  if (document.getElementById('formSuccess')) document.getElementById('formSuccess').style.display = 'block';
}

// Plan pre-select from URL
const params = new URLSearchParams(window.location.search);
if (params.get('plan') && document.getElementById('fplan')) {
  document.getElementById('fplan').value = params.get('plan');
}

// Scroll top button
window.addEventListener('scroll', () => {
  const st = document.getElementById('scrollTop');
  if (st) st.classList.toggle('show', window.scrollY > 400);
});

// Reveal animations
const obs = new IntersectionObserver(e => {
  e.forEach(x => { if (x.isIntersecting) x.target.classList.add('on') });
}, { threshold: .06, rootMargin: '0px 0px -30px 0px' });
document.querySelectorAll('.rv').forEach(el => obs.observe(el));

// Cursor glow follow effect
const cursorGlow = document.querySelector('.hero-cursor-glow');
if (cursorGlow) {
  document.addEventListener('mousemove', (e) => {
    cursorGlow.style.transform = `translate(${e.clientX - 150}px, ${e.clientY - 150}px)`;
  });
}
